/*
[氏名]
[学生番号]
*/

#include <stdio.h>

int main(void)
{
    printf("15から37を引いた値は%dです\n", 15 - 37);

    return 0;
}
