/*
[氏名]     南山太郎
[学生番号] 15se999
*/

#include <stdio.h>

void hello(void)
{
    printf("こんにちは。\n");
}

int main(void)
{
    hello();

    return 0;
}

/*
  実行結果

$ ./a.out
私の名前は南山太郎です。
私の趣味は貯金です。
$

*/
