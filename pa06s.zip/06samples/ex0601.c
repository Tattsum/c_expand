/*
[氏名]     南山太郎
[学生番号] 17se999
*/

#include <stdio.h>

int main(void)
{
	putchar('N');
	putchar('a');
	putchar('n');
	putchar('z');
	putchar('a');
	putchar('n');
	putchar(' ');
	putchar('U');
	putchar('n');
	putchar('i');
	putchar('v');
	putchar('\n');

    return 0;
}

/*
  実行結果

$ ./a.out
Nanzan Univ
$ 

*/
