/*
[氏名]     南山太郎
[学生番号] 17se999
*/

#include <stdio.h>

int main(void)
{
	int ch;

	while ((ch = getchar()) != EOF) {
		putchar(ch);
	}

    return 0;
}

/*
  実行結果

$ ./a.out
Hi, How're You Doin' ?
Hi, How're You Doin' ?
APPROACH
APPROACH
$ 

*/
